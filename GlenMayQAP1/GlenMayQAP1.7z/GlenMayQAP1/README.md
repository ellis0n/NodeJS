A quick look at core objects and modules found in NodeJS as coursework.

Please note the files directory should only contain simple txt files for the purposes of illustrating the modules referenced in the code. I hope this is falls under the bounds of acceptable file structure for the QAP as I did not include the node_modules directory as requested and there is virtually no excessive storage utilization.

You can run the individual .js files to see the readouts from the code, or the index.js file to see it all in one bang. I decided to leave descriptive language out of the console logs, and only printout functionality. I have left my authorial voice in the comments!

Everything else is straight forward: I looked at 6 global objects and many of their methods. For NPM, I used lodash and moment.
Github link:

https://github.com/ellis0n/NodeJS
